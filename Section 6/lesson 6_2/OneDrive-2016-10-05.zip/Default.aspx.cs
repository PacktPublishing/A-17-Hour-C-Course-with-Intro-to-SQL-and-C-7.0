﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
static class StringUtil //4. Class represents a collection of operations or methods only
{
    //5. Public means reachable anywhere
    //6. static means we can call the method by writing: StringUtil.Reverse
    //7. string is what we're going to produce and the method name is Reverse
    //8. string s is the data type and name of parameter
    public static string Reverse(string s)
    {
        var chars = s.ToCharArray();//9. Converts string to array of characters and saves to chars
        Array.Reverse(chars);//10. This has the action of reversing the array: 1,2,3 after reversing it's 3,2,1
        return new string(chars);//11. This creates a new string from the reversed array and sends it back to the calling code
    }
}

public partial class _Default : System.Web.UI.Page
{

    protected void Button1_Click(object sender, System.EventArgs e)
    {
        //12. Text1.Text reads value from box
        //13. That value is passed into Reverse method
        //14. After Reverse runs, it produces a string back to the user 
        Label1.Text = StringUtil.Reverse(TextBox1.Text);
    }
}

