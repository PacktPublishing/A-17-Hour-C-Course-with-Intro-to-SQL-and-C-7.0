﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;

class BankAccount//4. Class functions as a template for creating bank accounts
{
    private decimal balance;//5. private means this variable is reachable only within the bank account class
                            //6. decimal is the data type
                            //7. balance is the name of our instance variable or some people call it a field
                            //8  balance stores information about each bank account
    public BankAccount(decimal bal)//9. This is the constructor, which runs when a bank account is made
    {
        balance = bal;//10. This line sets the value of instance variable when ever a new bank account is created
    }
    public string GetBalance()//11. This method is public and gets the balance formatted as a string
    {
        return $"Balance: {balance:C}";//12. Shows balance formatted as currency
    }
} 
public partial class _Default : System.Web.UI.Page
{

    protected void Button1_Click(object sender, EventArgs e)
    {
        BankAccount ba = new BankAccount(4500);//13. Creates a new bank account 
        Label1.Text = ba.GetBalance();//14. Runs GetBalance method on the bank account object
    }
}

