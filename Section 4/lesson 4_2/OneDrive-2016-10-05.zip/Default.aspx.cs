﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
//4. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{
    //5. Code below is where we place our own code
    //6. Button1_Click is code that runs when a page loads from a server
    protected void Button1_Click(object sender, EventArgs e)
    {
        //7. Line below ensures entries are present in both boxes
        if(TextBox1.Text!="" && TextBox2.Text !="")
        {
            Label1.Text = "Your entries have been saved";//8. Line runs when both boxes are filled
        }
        else
        {
            Label1.Text = "Both entries must be specified.";//9. Runs when one box, or the other box,
        }                                                   //   or both boxes are empty
    }
}

