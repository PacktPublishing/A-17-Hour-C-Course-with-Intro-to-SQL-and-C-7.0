﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
//4. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{
    //5. Code below runs when submit button is clicked
    protected void Button1_Click(object sender, EventArgs e)
    {
        //6. In English, we'd say: is box 1, or box2, or potentially both boxes, checked
        if(CheckBox1.Checked || CheckBox2.Checked)
        {
            Label1.Text = "You do not qualify for a discount";//7. Runs when one box, or the other, both are checked
        }
        else
        {
            Label1.Text = "You do qualify for a discount";//8. Runs when neither box is checked
        }
    }
}

