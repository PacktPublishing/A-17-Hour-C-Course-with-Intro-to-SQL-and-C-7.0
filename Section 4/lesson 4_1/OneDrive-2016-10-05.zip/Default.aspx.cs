﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
//4. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{
    //5. Code below is where we place our own code
    //6. Button1_Click is code that runs when a page loads from a server
    protected void Button1_Click(object sender, EventArgs e)
    {
        double x = 25;//7. Declares and sets a variable so we can illustrate some basic concepts
        Label1.Text = $"x={++x}";//8. ++x runs first, which means x will shows 26, NOT 25
        //9. Code below x+=2 means the same thing as x=x+2: grab x, add 2 to it ,and store back to x
        Label1.Text += $"<br>x+2={x += 2}";
        //10. --x has the action of decreasing x by 1 and then printing the updated value
        Label1.Text += $"<br>x-1={--x}";
        //11. == checks whether two quantities are equal or not
        Label1.Text += $"<br>Does x equal 3? " + (x == 3);
    
    }
}

