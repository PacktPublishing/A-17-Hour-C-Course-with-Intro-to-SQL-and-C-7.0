﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
//4. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{

    //5. interest is the result of a calculation done inside the method, so it's an out parameter
    //6. value is needed to calculate the interest, but it's set in Button1_Click
    private static void GetValueAndInterest(out decimal interest, ref decimal value)
    {
        interest = 0.05M * value;//7. Finds interest and saves it to the interest out value
        value = value + interest;//8. Line updates how much money there with the new interested added to it
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        //9. This is the money on which we want to find the interest
        decimal principle = 4500;//10. This goes in with ref keyword, so it's value has to be set here
        decimal interest;//11. This is our out value. It does not have to be set here. 
        GetValueAndInterest(out interest, ref principle);
        Label1.Text = $"Final Amount is {principle:C}";//12. Prints updated value
        Label1.Text += $"<br>Interest is {interest:C}";//13. Prints interest to screen
    }
}

