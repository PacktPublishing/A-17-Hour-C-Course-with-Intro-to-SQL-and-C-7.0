﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
//4. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{


    protected void Button1_Click1(object sender, EventArgs e)
    {
        string[] s = { "h", "e", "y" }; //5. Makes array of strings 
        //6. As loop runs, c stands for h, then e, and then the letter 
        foreach (string c in s)//7. Needed so each letter can grabbed
            Label1.Text += $"<br>{c}";//8. Prints each letter in a column

    }
}

