﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
//4. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{
    //5. params keyword allows us to pass a variable number of values into a method
    //6. Product(1,2) or Product(1,2,4) or Product(-3,4,3,6)
    private static double Product(params double[] arr)
    {
        double product = 1;//7. 1*2*4=8, 1*5*4*3=60, begin with 1 as the initial value of product

        foreach (double d in arr)//8. Grab each value inside the array
            product *= d;//9. This line makes the product grow until the loop ends

        return product;//10. Sends the product back to the calling code
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        double x = 5, y = 10, z = 15;//11. Declares and sets values of the same data type
        Label1.Text = $"{x}*{y}={Product(x, y)}";//12. Calls Product with x and y as the arguments
        Label1.Text += $"<br>{x}*{y}*{z}={Product(x, y, z)}";//13. Calls Product with x, y and z as arguments

    }
}

