﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
//4. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{
    //5. values is the array that is the parameter
    private static double Sum(double[] values)
    {
        double sum = 0;//6. Begin sum with 0 so its value does not change the sum

        foreach (double d in values)//7. Grabs each entry inside the array
            sum += d;//8. sum+=d has the action of adding up the values as the loop operates

        return sum;//9. Returns sum at the end of the method
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        double[] vals = { 4, 5, 9, -10, 2 };//10. Creates an array of doubles so we have something to add up

        //1. Line below calls the Sum method and the result is then printed on the web page
        Label1.Text = $"Sum of values is {Sum(vals)}";
    }
}

