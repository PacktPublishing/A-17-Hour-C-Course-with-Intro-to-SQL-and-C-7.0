﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
//4. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{
    //5. void means do not send a value like 10 back to the calling code
    private static void ChangeArray(int[] arr)
    {
        arr[0] = 10;//6. This line changes the value stored at index 0. This change is visible in the calling code. 
    }
    private static void ChangeValue(double x)
    {
        x = 30;//7. Setting the value 30 to x will not change the argument where the method is called
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        int[] arr1 = { 1, 2 };//8. Creates a simple array
        ChangeArray(arr1);//9. Calls a method and passes in the array
        Label1.Text = $"The value at index 0 is {arr1[0]}";//10. Does arr1[0] shows 1 or does it show 10

        double z = 25;//11. Creates a variable 
        ChangeValue(z);//12. z is the argument that is passed into the method named ChangeValue passed as a copy
        Label1.Text += $"<br>The value of z is now {z}";//13. 
    }
}

