﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
using System.Linq; //4. Needed to allow using methods like Sum and Average 
//5. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{
    //6. out keyword indicates that average value will be set inside Summarize
    //7. average is also available in other methods
    //8. keep in mind this method also still returns a value of type double to the calling code
    private static double Summarize(double[] values, out double average)
    {
        average = values.Average();//9. Uses Average extension method to find average of values inside array
                                   //10. This average found is used to set the value of average out parameter
        return values.Sum();//11. This line sends the sum back to the calling code
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        var vals = new double[] { 4, 5, 6, 8, 8, 9, 10, -40 };//12. Creates an array to operate on
        double average;//13. This will be used to call Summarize. It's value does not have to bet set here. 
        //14. Line below calls Summarize with value array and sets the average value
        Label1.Text = $"Sum of values={Summarize(vals, out average)}";
        Label1.Text += $"<br>Average of values is ={average}";//15. Line displays average
    }
}

