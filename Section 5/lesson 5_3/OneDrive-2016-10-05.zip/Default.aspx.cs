﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
//4. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{
    //5. private means this method is reachable only within this class
    //6. static means we can call this method directly by just its name
    //7. double is the data type of the value returned by a  method
    //8. GetIncreasedValue is the name of the method
    //9. double x is the data type and name of a parameter
    //10. Parameters serve as place holders through which values are passed into methods
    private static double GetIncreasedValue(double x)
    {
        return x * 1.1;//11. Sends the value of x*1.1 back to the calling code
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        //12. Line below reads value from box and converts to numerical form and saves to variable
        double value = Convert.ToDouble(TextBox1.Text);
        //13. value is called the argument because it's the value passed into the method so the method 
        //14. can operate on it and produce a result
        double result = GetIncreasedValue(value);
        Label1.Text = $"{value} increased by 10% is {result}";//15. Shows value to user increase by 10%
    }
}

