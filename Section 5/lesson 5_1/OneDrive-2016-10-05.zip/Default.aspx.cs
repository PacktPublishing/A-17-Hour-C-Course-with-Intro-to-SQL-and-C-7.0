﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
//4. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{

    protected void Button1_Click(object sender, EventArgs e)
    {
        decimal[] values = new decimal[2];//5. This line creates an array of length 2, or it can store 2 entries
        //6. index in this context is just the same as saying address: 0,1 and NOT 1,2
        values[0] = decimal.Parse(TextBox1.Text);//7. Converts and saves value from box to array at index 0
        values[1] = decimal.Parse(TextBox2.Text);//8. Converts and saves value from box to array at index 1
        decimal total = values[0] + values[1];//9. Add the two values in the array and store to total variable
        Label1.Text = $"Total is {total:C}";//10. Displays total value formatted as currency
        //11. Line below total/values.Length because total is the result of adding the entries
        //12. values.Length tells you how many entries there are
        Label1.Text += $"<br>Average is {total / values.Length:C}";
    }
}

