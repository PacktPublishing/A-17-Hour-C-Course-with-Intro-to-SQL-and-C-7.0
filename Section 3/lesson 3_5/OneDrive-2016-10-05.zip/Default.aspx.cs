﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
//4. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{
    //5. Code below is where we place our own code
    //6. Page_Load is code that runs when a page loads from a server
    protected void Page_Load(object sender, EventArgs e)
    {
  
    }

    protected void TextBox1_TextChanged1(object sender, EventArgs e)
    {
        string input = TextBox1.Text;//7. REads value from box and saves to input variable
        foreach (char c in input)//8. This means grab each letter in the string
            Label1.Text += $"<br>{c}";//9. Prints c to the page in a vertical column
    }                          
}

