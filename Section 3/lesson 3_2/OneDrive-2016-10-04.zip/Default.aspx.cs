﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
//4. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{
    //5. Code below is where we place our own code
    //6. Page_Load is code that runs when a page loads from a server
    protected void Page_Load(object sender, EventArgs e)
    {
        int x = 5;//7. Variable is needed so we have something whose values can grow
        x++;//8. x++ has the result of making the value of x grow by 1
        sampLabel.Text = $"The current value of x is {x}";
        x = x + 1;//9. x=x+1 means: grab x, grow its value by 1 and store the value back to x
        sampLabel.Text += $"<br>The current value of x is {x}";
    }
}

