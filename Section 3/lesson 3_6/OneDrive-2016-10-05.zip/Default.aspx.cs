﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
//4. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{
    //5. Code below is where we place our own code
    //6. Page_Load is code that runs when a page loads from a server
    protected void Page_Load(object sender, EventArgs e)
    {
  
    }



    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        switch(DropDownList1.SelectedValue)//Switches based on what the user has selected on a web page
        {
            case "Pears"://7. case label runs when the user selects Pears on the page
                Page.Title = "Pears";//8. sets title of page as program runs
                Label1.Text = "Pears cost 25\u00A2 each. ";//9. Fill label on page with some information
                break;//10. Leave the switch block

            case "Apples"://11. case label runs when the user selects Apples on the page
                Page.Title = "Apples";//12. sets title of page as program runs
                Label1.Text = "Apples cost 50\u00A2 each. ";//13. Fill label on page with some information
                break;//14. Leave the switch block

            case "Mangos": //15. Runs when user selects Mangos on web page
                Page.Title = "Mangos";//16. sets title of page as program runs
                Label1.Text = "Mangos cost 75\u00A2 each. ";//17. Fill label on page with some information
                break;//18. Leave the switch block
        }
    }
}

