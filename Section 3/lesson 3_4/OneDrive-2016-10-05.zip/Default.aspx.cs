﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
//4. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{
    //5. Code below is where we place our own code
    //6. Page_Load is code that runs when a page loads from a server
    protected void Page_Load(object sender, EventArgs e)
    {
  
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        ListBox1.Items.Clear();//7. Needed to clear box so output does not accumulate
        //8. int i=1 simply means the first value to show in the box will be 1
        //9. i<=10 is the logical condition that makes the loop until say, i=11, and then the condition fails
        //10. i++ is needed to keep the value of i growing

        for (int i = 1; i <= 20; i++)
            ListBox1.Items.Add(i.ToString());//11. i.ToString() takes 5 and produces "5"
    }
}

