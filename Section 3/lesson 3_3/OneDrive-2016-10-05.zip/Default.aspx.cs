﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
//4. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{
    //5. Code below is where we place our own code
    //6. Page_Load is code that runs when a page loads from a server
    protected void Page_Load(object sender, EventArgs e)
    {
  
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        int howManyTimes = 25;//7. Value tells how many times in all a loop will run
        int counter = 1;//8. This variable keeps the loop going
        //9. counter<=howManyTimes is the logical condition that controls the operation of the loop
        //10. once counter variable is greater than howManyTimes, the loop fails
        while (counter<=howManyTimes)
        {
            //11. Math.Pow(counter,2) means square the value of the counter: 1, 1*1=1, 2*2=4, 3*3=9
            sampLabel.Text += $"<br>{counter}^2={Math.Pow(counter, 2)}";
            counter++;//12. counter++ grows the counter by 1 every time the loop runs
        }

    }
}

