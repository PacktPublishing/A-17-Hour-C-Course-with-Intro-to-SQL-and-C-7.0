﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
//4. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{
    //5. Code below is where we place our own code
    //6. Page_Load is code that runs when a page loads from a server
    protected void Page_Load(object sender, EventArgs e)
    {
  
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        double xOut;//7. Variable is needed so that TryParse can operate as it's been designed to do
        //8. Line below says: take text from box, and if possible, convert it to a numerical value
        //9. If "ten", this cannot be converted to the number 10. 
        //10. An input like "10", on the other hand, can be converted to a number like 10, without the double quotes

        if(double.TryParse(TextBox1.Text,out xOut))
        {
            Label1.Text = $"{xOut} increased by 10% is {xOut * 1.1}";//10. Line runs when input can be converted
        }                                                            //11. successfully to numerical form: 10
        else
        {
            Label1.Text = "Input cannot be treated as a numerical value.";//12. Runs when input cannot be converted
        }
    }
}

