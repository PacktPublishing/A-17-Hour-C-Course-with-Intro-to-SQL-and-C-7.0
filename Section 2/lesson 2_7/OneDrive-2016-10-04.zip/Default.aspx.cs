﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
//4. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{
    //5. Code below is where we place our own code
    //6. Page_Load is code that runs when a page loads from a server
    protected void Page_Load(object sender, EventArgs e)
    {
        //7. line declares and sets two variables to represent two different salaries
        decimal salaryOne = 25000, salaryTwo = 65000;

        //8. Values are added on the right side, and the result is another decimal type
        //9. The result is saved to the variable named totalSalary
        //10. totalSalary is a computed variable or calculated variable
        decimal totalSalary=salaryOne + salaryTwo;
        sampLabel.Text = $"Total salary is {totalSalary:C}";

        //1. totalSalary/2 is the average salary
        decimal averageSalary = totalSalary / 2;
        sampLabel.Text += $"<br>The average salary is {averageSalary:C}";


    }
}

