﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
//4. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{
    //5. Code below is where we place our own code
    //6. Page_Load is code that runs when a page loads from a server
    protected void Page_Load(object sender, EventArgs e)
    {       


    }

    //7. Code below runs when the text is changed inside our little box
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        //8. First read the value from the text property of the box
        string input = TextBox1.Text;
        //9. Convert is a class that stores the ToDouble method
        //10. A method is a block of code that accepts input, operates on the input and produces output
        double x = Convert.ToDouble(input);
        //1. x*1.1 produces 110% of the value of x and this value is then printed on the screen
        sampLabel.Text = $"{x} increased by 10% is {x * 1.1}";
    }
}

