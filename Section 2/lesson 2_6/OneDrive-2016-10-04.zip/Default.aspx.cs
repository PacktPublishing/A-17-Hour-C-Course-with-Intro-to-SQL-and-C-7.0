﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;

//4. class is a required container for creating our own code samples

public partial class _Default : System.Web.UI.Page
{
    //5. Code below is where we place our own code
    //6. Page_Load is code that runs when a page loads from a server
    protected void Page_Load(object sender, EventArgs e)
    {
        //7. Sets value of page title so it can be controlled dynamically
        Page.Title = "Table Catalog";

        string desc = "This is a fancy table from France"; //8. Stores desc. of table
        sampLabel.Text = desc;//9. Assigns desc to text property of label for displays purposes

        bool extendable = true;//10. Variable tells whether a table can be made longer
        sampLabel.Text += $"<br>Extendable:{extendable}";

        decimal price = 399.99M;//11. Stores price of table 
        sampLabel.Text += $"<br>Price:{price:C}";//12. Prints price of table



    }
}

