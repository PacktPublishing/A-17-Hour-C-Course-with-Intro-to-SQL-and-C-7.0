﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;

//4. class is a required container for creating our own code samples

public partial class _Default : System.Web.UI.Page
{
    //5. Code below is where we place our own code
    //6. Page_Load is code that runs when a page loads from a server
    protected void Page_Load(object sender, EventArgs e)
    {
        double x = 25.098114;//7. Value is needed so we have something to format
        //8. {x:C} prints the value of x formatted as currency
        sampLabel.Text = $"{x} formatted as currency is {x:C}";
        x = 0.349533;//9. Saving a decimal so the percent P2 specifier is easier to see in action
        //10. {x:P2} shows the value of x formatted as a percent
        sampLabel.Text += $"<br>{x} formatted as a percent is {x:P2}";
        //11. To show a date, use DateTime.Now
        //12. To actually get the date, {DateTime.Now:d}
        sampLabel.Text += $"<br>Today's date is {DateTime.Now:d}";
             
    }
}

