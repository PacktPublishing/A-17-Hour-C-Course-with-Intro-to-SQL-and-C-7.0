﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;

//4. class is a required container for creating our own code samples

public partial class _Default : System.Web.UI.Page
{
    //5. Code below is where we place our own code
    //6. Page_Load is code that runs when a page loads from a server
    protected void Page_Load(object sender, EventArgs e)
    {
        //7. You see a group of people and the height changes from person to person
        //8. Introduce a variable like height to represent these changing values
        double height = 65.00;//9. Declares and set a variable value
        sampLabel.Text = "John's height is " + height;
        height = 55.5;//10. Assigns new value to represent a new height
        //11.+= appends new text to existing text so that Mary's height
        //12.prints after John's height
        sampLabel.Text += "<br>Mary's height is " + height;
    }
}