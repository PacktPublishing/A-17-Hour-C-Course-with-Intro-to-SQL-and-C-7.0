﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;
//4. class is a required container for creating our own code samples
public partial class _Default : System.Web.UI.Page
{
    //5. Code below is where we place our own code
    //6. Page_Load is code that runs when a page loads from a server
    protected void Page_Load(object sender, EventArgs e)
    {       
        

    }


    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        //7. First get text from text box
        //8. Run ToLower to convert the input to lower case
        //9. Check for presence of letter e in the input
        //10. Contains method gives a true or false kind of result
        bool isLetterPresent = (TextBox1.Text).ToLower().Contains("e");

        sampLabel.Text = $"It's {isLetterPresent} that your input contains the letter e.";
    }
}

