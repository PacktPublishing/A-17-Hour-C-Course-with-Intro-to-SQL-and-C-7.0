﻿//1. using is a keyword, it's blue
//2. System is a name space that stores already created code
//3. using System brings in existing code
using System;

//4. class is a required container for creating our own code samples

public partial class _Default : System.Web.UI.Page
{
    //5. Code below is where we place our own code
    //6. Page_Load is code that runs when a page loads from a server
    protected void Page_Load(object sender, EventArgs e)
    {
        double height = 65;//7. Creates and assign a variable
        //8. $ makes string interpolation work
        //9. String interpolation allows us to put variable names directly into strings
        //10. Make sure to update VS 2015 Community With the NuGet package that installs
        //11. the updated Microsoft CodeDom so the updated version of C# is used. This means
        //12. C# 6.0 should be installed so string interpolation below works.
        sampLabel.Text = $"Height is {height}";        
    }
}